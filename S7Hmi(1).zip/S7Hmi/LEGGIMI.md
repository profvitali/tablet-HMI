# S7 HMI – pannello operatore per tablet Android (S7-1200 / 1214C)

Pannello HMI progettabile liberamente sul tablet, che parla direttamente col PLC via Ethernet/Wi-Fi (porta 102),
senza librerie esterne (client S7comm scritto da zero in `S7Client.kt`).

## Oggetti disponibili
- **Pulsante monostabile**: scrive 1 finché lo tieni premuto, 0 al rilascio (bit di un DB).
- **Pulsante bistabile**: a ogni tocco inverte il bit; si accende in base allo stato letto dal PLC.
- **Visualizza valore** (uscita) e **Immetti valore** (ingresso, tocchi e digiti): BYTE, INT, DINT, REAL; limiti opzionali.
- **Vai a pagina**: pulsante di navigazione (pagina scelta, successiva o precedente), funziona anche senza PLC.
- Spia, barra livello, allarme lampeggiante, testo.
- Ogni oggetto: DB, offset, bit, colore. Sfondo: una tua immagine (meglio in formato 16:10, per non deformarla).

## 1. Preparare il PLC (TIA Portal)
1. Nel DB: Proprietà > Attributi > **disattiva "Accesso ottimizzato al blocco"**, poi compila.
2. Proprietà CPU > Protezione e Security > Meccanismi di connessione > **"Consenti accesso PUT/GET dal partner remoto"**.
3. Livello di protezione CPU: accesso completo (nessuna protezione) oppure password che consenta PUT/GET.
4. Scarica nel PLC. Collega la porta Ethernet del PLC al router/access point; il tablet va sullo stesso Wi-Fi (stessa subnet, es. 192.168.0.x).

## 2. Ottenere l'APK senza Android Studio (GitHub Actions)
1. Crea un account GitHub e un repository nuovo (privato va bene).
2. Carica TUTTO il contenuto della cartella `S7Hmi` (compresa la cartella nascosta `.github`) nel ramo `main`.
3. Scheda **Actions** > "Build APK" > **Run workflow**. Dopo qualche minuto scarica l'artefatto `S7Hmi-apk` (contiene `app-debug.apk`).
4. Sul tablet: copia l'APK, aprilo e consenti «Installa app sconosciute» per l'app con cui lo apri.
(In alternativa: apri la cartella con Android Studio e premi Run.)

## 3. Progettare il pannello
1. Tasto **PLC**: IP del PLC, rack 0, slot 1.
2. **Modifica** > **+ Oggetto**: scegli il tipo, nome, indirizzo (DB / offset / bit), colore. Appare al centro.
3. **Trascina** l'oggetto per spostarlo; **trascina il quadratino in basso a destra** per ridimensionarlo. Si aggancia a una griglia.
4. **Tocca** un oggetto (in modifica) per cambiarlo, duplicarlo o eliminarlo. **Sfondo** carica un'immagine.
5. **Fine modifica**: il pannello è operativo e si aggiorna ogni ~300 ms. Tutto resta salvato sul tablet.

## Pagine
- Ogni progetto ha più pagine, ciascuna con i suoi oggetti e il suo sfondo.
- **Modifica**: sotto la barra in alto compaiono le schede e i tasti «+ Pagina», «Rinomina», ◀ ▶ (ordine) ed «Elimina pagina».
- **In funzione** si cambia pagina toccando le schede in alto, oppure con gli oggetti «Vai a pagina» messi dove vuoi.
  Dal tasto «PLC» puoi nascondere le schede e usare solo i pulsanti.
- Si leggono dal PLC solo gli oggetti della pagina visibile (meno traffico, aggiornamento più rapido).
  Gli allarmi di una pagina non visibile quindi non vengono mostrati finché non la apri.

## Non ancora presenti
Più PLC, backup della configurazione, trend, Modbus TCP, conferma allarmi, diagnostica RUN/STOP.
